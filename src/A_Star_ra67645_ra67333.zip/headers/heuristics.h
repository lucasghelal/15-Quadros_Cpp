#ifndef HEURISTICS_H
#define HEURISTICS_H

float out_of_order_heuristic(int[][4]);
float out_of_sequence_heuristic(int[][4]);
float rect_distance_heuristic(int[][4]);

#endif
